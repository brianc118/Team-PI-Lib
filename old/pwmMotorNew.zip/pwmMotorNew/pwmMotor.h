/*
    omnidrive - Library for omnidirectional movement
    Created by Brian Chen 05/01/2014
    Last Modified by Brian Chen 06/01/2014 2:26pm

    Beta 0.8
*/


#ifndef pwmMotor_h
#define pwmMotor_h

#include "Arduino.h"

class PMOTOR
{
public:
    PMOTOR(uint8_t pwm_pin, uint8_t direction_pin, uint8_t brk_pin, uint8_t cs_pin, bool dir, uint16_t freq);
    void move(int16_t input);
    uint16_t current();
private:
    uint8_t pwm;	// pwm pin
    uint8_t d;	    // direction pin
    uint8_t b;	    // brake pin
    uint8_t c;      // current pin
    uint8_t DHIGH;	// values to store high/low values for direction control
    uint8_t DLOW;
};

#endif
