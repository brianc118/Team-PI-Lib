/*
    omnidrive - Library for omnidirectional movement
    Created by Brian Chen 05/01/2014
    Last Modified by Brian Chen 06/01/2014 2:26pm

    Beta 0.7
*/


#include "Arduino.h"
#include "pwmMotor.h"

PMOTOR::PMOTOR(uint8_t pwm_pin, uint8_t direction_pin, uint8_t brk_pin, uint8_t cs_pin, bool dir, uint16_t freq)
{
	pwm = pwm_pin;
	d = direction_pin;
	b = brk_pin;
	c = cs_pin;
	if (!freq == 0){		// frequency is default if passed as 0
		analogWriteFrequency(pwm, freq);
	}
	pinMode(pwm, OUTPUT);
	pinMode(d, OUTPUT);
	pinMode(b, OUTPUT);
	pinMode(c, INPUT);

	if (!dir){
		DHIGH = LOW;
		DLOW = HIGH;
	}
	else{
		DHIGH = HIGH;
		DLOW = LOW;
	}
}


//simple move function to drive the motor
void PMOTOR::move(int16_t input){
	if(input < 0){
		digitalWrite(d,DHIGH);	
		digitalWrite(b,LOW);
		analogWrite(pwm, abs(input));
	}
	else if(input > 0){
		digitalWrite(d,DLOW);
		digitalWrite(b,LOW);
		analogWrite(pwm, abs(input));
	}
	else{
		//following code used to enable brake. Comment out if necessary.
		digitalWrite(b,HIGH);
		analogWrite(pwm, abs(input));
	}	
}

uint16_t PMOTOR::current(){
	return analogRead(c);
}