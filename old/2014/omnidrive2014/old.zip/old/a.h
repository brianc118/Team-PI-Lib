/*
    omnidrive - Library for omnidirectional movement
    Created by Brian Chen 05/01/2014
    Last Modified by Brian Chen 06/01/2014 2:26pm

    Beta 0.7
*/


#ifndef omnidrive_h
#define omnidrive_h

#include "Arduino.h"
#include "pwmMotor.h"

#define MAX 255

class OMNIDRIVE
{
public:
    OMNIDRIVE(PMOTOR _motorA, PMOTOR _motorB, PMOTOR _motorC);
    int16_t move(int16_t angle, uint8_t speed, int16_t angularVelocity);
private:
    PMOTOR motorA, motorB, motorC;     
};
#endif

